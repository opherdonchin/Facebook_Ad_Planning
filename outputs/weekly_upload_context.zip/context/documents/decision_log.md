# Weekly Decision Log

# Plan for 2026-W24 (assessing 2026-W23)

### Weeks

- **Assessed (data) week:** 2026-W23
- **Decision / planned week:** 2026-W24
- **Operational note:** decision made Sunday, four days after the normal Thursday update point. Partial 2026-W24 data exists in the export and is used only as in-flight evidence.

### Ads active in assessed week (2026-W23)

- Men: Mens Ad J, M 2605_1

| Ad name | Spend | CPL | Lifetime spend | Lifetime CPL |
| --- | --- | --- | --- | --- |
| Mens Ad J | 241.69 | 26.85 | 2278.87 | 35.06 |
| M 2605_1 | 33.66 | 11.22 | 204.72 | 51.18 |

- Women: W 2605_1, W 2603_1, Womens Ad P, W 2603_2

| Ad name | Spend | CPL | Lifetime spend | Lifetime CPL |
| --- | --- | --- | --- | --- |
| W 2605_1 | 130.57 | 43.52 | 310.68 | 51.78 |
| W 2603_1 | 125.15 | 15.64 | 508.21 | 33.88 |
| Womens Ad P | 16.13 | —   | 884.89 | 55.31 |
| W 2603_2 | 3.54 | —   | 421.53 | 84.31 |

### Ads planned for decision week (2026-W24)

- Men: Mens Ad J, M 2605_1

#### Reuse:

| Name | Spend | CPL | Lifetime spend | Lifetime CPL |
| --- | --- | --- | --- | --- |
| Mens Ad J | 241.69 | 26.85 | 2278.87 | 35.06 |
| M 2605_1 | 33.66 | 11.22 | 204.72 | 51.18 |

#### Reshuffle:

None.

#### New content

None.

- Women: W 2603_1, Womens Ad P

#### Reuse:

| Name | Spend | CPL | Lifetime spend | Lifetime CPL |
| --- | --- | --- | --- | --- |
| W 2603_1 | 125.15 | 15.64 | 508.21 | 33.88 |
| Womens Ad P | 16.13 | —   | 884.89 | 55.31 |

#### Reshuffle:

None.

#### New content

None.

---

## Portfolio decision

- Keep `Mens Ad J`.
- Keep `M 2605_1`.
- Keep `W 2603_1`.
- Keep `Womens Ad P` as the second women’s slot, primarily under the low-delivery rule.
- No new material and no reshuffle are recommended for `2026-W24`.

---

## Rationale concise

- `Mens Ad J` recovered strongly in `2026-W23` and is also excellent in partial `2026-W24`; this is the men’s anchor.
- `M 2605_1` generated 3 leads at 11.22 CPL in `2026-W23`; evidence is still limited, but replacing it immediately would be premature.
- `W 2603_1` is the women’s anchor: 8 leads at 15.64 CPL in `2026-W23`, 10 leads at 21.96 CPL in the current run through the export.
- `W 2605_1` also performed acceptably in `2026-W23`, but it cannot be planned together with `W 2603_1` because both use `Quiet Space - Bullet Calm` as primary text. `W 2603_1` has the stronger current-run and lifetime evidence.
- `Womens Ad P` is weak historically and has almost no current delivery, but current-run spend is only 16.92 ILS through the export, so it remains a low-delivery keep rather than a failure.
- Because the `2026-W24` update is already four days late, stability is preferred unless a current ad clearly fails the keep rules.

---

## Constraints check

- **Creative uniqueness:** satisfied for `2026-W24`; no media, headline, or primary text is duplicated within the men’s or women’s campaign.
- **New-material constraint:** satisfied; zero new media, headlines, or primary texts.
- **Media provenance:** all planned media are present in `attachments_manifest.json` and `attachments.tar`:
  - `Tenshinage_lineart_controlled` → `attachments/Media/Tenshinage_lineart_controlled.jpg`
  - `Dojo_ClassScene_Ikkyo_MF_Class_Scene` → `attachments/Media/Dojo_ClassScene_Ikkyo_MF_Class_Scene.png`
  - `Shihonage_MF_Dojo_Photo` → `attachments/Media/Shihonage_MF_Dojo_Photo__A.png`
  - `Dojo_Instruction_FemalePair` → `attachments/Media/Dojo_Instruction_FemalePair.png`
- **Image-text semantic check:** passed after inspecting the actual media assets.
- **Gender/campaign integrity:** no blocking mismatch identified.
- **Most recent new-material alternation:** not relevant because no new material is introduced.

---

## Data hygiene / learning notes

- `2026-W23` contains transition/carryover activity: more than four ads show spend, but meaningful spend and current `2026-W24` intended-run flags make the planned `2026-W24` portfolio clear.
- `W 2603_2` has only 3.54 ILS spend in `2026-W23` and should be treated as trailing spend, not a decision signal.
- `Womens Ad P` had 16.13 ILS spend in `2026-W23` and 0.79 ILS in partial `2026-W24`, so there is still no meaningful read on the current run.
- `ad_components.csv` omits headline fields for several old ads; where needed, headline assignments were reconstructed from `performance_data.json` / `Ads` and `Headlines`.

---

## What would change this decision next week

- If `Womens Ad P` still does not deliver by the end of full `2026-W24`, replace it.
- If `M 2605_1` receives meaningful spend and fails to add leads, replace it with a stronger historical male fallback, likely `Mens Ad A` or a controlled reshuffle.
- If `Mens Ad J` and `W 2603_1` remain strong, continue treating them as the two campaign anchors.
- If the women’s second slot needs replacement, avoid using `Quiet Space - Bullet Calm` unless `W 2603_1` is also being retired.

---

## Confidence level

**Moderate-high for keeping `Mens Ad J` and `W 2603_1`; moderate for keeping `M 2605_1`; low-to-moderate for keeping `Womens Ad P`, justified mostly by low delivery and by avoiding a Sunday mid-week reshuffle.**

---

End of Plan 2026-W24

---

# Plan for 2026-W23 (assessing 2026-W22)

### Weeks

- **Assessed (data) week:** 2026-W22
- **Decision / planned week:** 2026-W23
- **Partial mid-week evidence used:** 2026-W23 through Saturday; used only as an override signal, not as a completed assessed week.

### Ads active in assessed week (2026-W22)

- Men: Mens Ad J, M 2605_1

| Ad name | Spend | CPL | Lifetime spend | Lifetime CPL |
| --- | --- | --- | --- | --- |
| Mens Ad J | 225.77 | 112.89 | 1990.99 | 39.04 |
| M 2605_1 | 11.40 | —   | 181.63 | 90.82 |

- Women: W 2603_2, W 2605_1

| Ad name | Spend | CPL | Lifetime spend | Lifetime CPL |
| --- | --- | --- | --- | --- |
| W 2603_2 | 131.67 | 131.67 | 419.76 | 83.95 |
| W 2605_1 | 113.59 | 113.59 | 244.29 | 61.07 |

### Ads planned for decision week (2026-W23)

- Men: Mens Ad J, M 2605_1

#### Reuse:

| Name | Spend | CPL | Lifetime spend | Lifetime CPL |
| --- | --- | --- | --- | --- |
| Mens Ad J | 49.05 | 16.35 | 1990.99 | 39.04 |
| M 2605_1 | 12.76 | 12.76 | 181.63 | 90.82 |

#### Reshuffle:

None.

#### New content

None.

- Women: Womens Ad P, W 2603_1

#### Reuse:

| Name | Spend | CPL | Lifetime spend | Lifetime CPL |
| --- | --- | --- | --- | --- |
| Womens Ad P | —   | —   | 867.97 | 54.25 |
| W 2603_1 | —   | —   | 288.60 | 57.72 |

#### Reshuffle:

None.

#### New content

None.

---

## Portfolio decision

- **Men:** keep `Mens Ad J` and `M 2605_1` unchanged for the rest of `2026-W23`.
- **Women:** replace `W 2603_2` and `W 2605_1` immediately with `Womens Ad P` and `W 2603_1`.
- **New material:** none.

---

## Rationale concise

- `2026-W22` was poor across all four active ads, but the partial `2026-W23` data changes the men’s decision.
- `Mens Ad J` has 3 partial-week leads at 16.35 CPL and remains the strongest lifetime male ad.
- `M 2605_1` is still weak overall, but the single cheap `2026-W23` lead and low spend make it less urgent than the women’s campaign.
- `W 2603_2` has failed across the current run: 321.52 ILS, 2 leads, 160.76 run CPL, plus near-zero `2026-W23` delivery.
- `W 2605_1` is semantically coherent but remains above target and has not stabilized the women’s campaign.
- `Womens Ad P` and `W 2603_1` are cooled existing women’s ads with better historical evidence than the current women’s ads.

---

## Constraints check

- No new media, headline, or text is introduced.
- Exactly two existing-material changes are made.
- No component is duplicated within the men’s or women’s campaign for `2026-W23`.
- Replacement media are present in `attachments_manifest.json` and `attachments.tar`:
  - `Dojo_Instruction_FemalePair` → `attachments/Media/Dojo_Instruction_FemalePair.png`
  - `Shihonage_MF_Dojo_Photo` → `attachments/Media/Shihonage_MF_Dojo_Photo__A.png`
- Actual images were inspected and match their proposed headlines/texts well enough to run.
- No alternation decision for new material is required because no new material is used.

---

## Data hygiene / learning notes

- The uploaded `decision_log.md` ends at `2026-W19`; the user reports that a `2026-W20` plan exists externally. For this decision, current `intended_run` flags and W20–W23 performance data were used to identify the active ads.
- The `ad_components.csv` file has empty headline fields for several ads, but headline assignments were recoverable from `performance_data.json` / `Ads` and `Headlines`.
- `2026-W23` data is partial. A full `2026-W23` dataset should be used for the `2026-W24` decision.

---

## What would change this decision next week

- If full `2026-W23` confirms `Mens Ad J` near its partial-week result, keep it.
- If `M 2605_1` remains weak after full `2026-W23`, replace it in `2026-W24`; the leading exploitation candidate is `Mens Ad A`.
- If `Womens Ad P` or `W 2603_1` fail to deliver after the W23 switch, reassess against `Womens Ad A`, `W 2603_4`, and possible controlled recombination.
- If the full W23 women’s data improves sharply before the switch is implemented, revisit this decision before changing ads.

---

## Confidence level

**Moderate.**

The direction of the women’s change is clear. The men’s hold is less certain, but it is the least disruptive mid-week choice because partial W23 men’s performance has improved and the two-change limit is better spent on women.

---

End of Plan 2026-W23

---

## Decisions for 2026-W20

### Keep

| Campaign | Ad | Reason |
|---|---|---|
| M | Mens Ad J | W19 CPL 25.67; current-run CPL 25.67; lifetime CPL 35.46 |
| M | Mens Ad N | Current-run spend only 18.20 ILS; insufficient delivery to judge |
| W | Womens Ad A | W19 CPL 21.70; current-run CPL 27.68; lifetime CPL 39.10 |

### Replace

| Campaign | Remove | Replacement | Type | Components |
|---|---|---|---|---|
| W | Womens Ad J | W 2605_1 | Reshuffle existing materials | `Shihonage_MF_Dojo_Photo` + `מרחב שקט לעצמך` + `Quiet Space - Bullet Calm` |

### New content

None. No new headline, text, or media is proposed for 2026-W20.

---

## Rationale

- `Mens Ad J` is retained because it finally received delivery in 2026-W19 and performed strongly: 153.99 ILS spend, 6 leads, CPL 25.67.
- `Mens Ad N` is retained under the low-delivery rule. It spent only 18.20 ILS in its current run, so the no-lead result is not yet informative enough to replace it.
- `Womens Ad A` remains the women’s anchor: current-run spend 276.80 ILS, 10 leads, CPL 27.68.
- `Womens Ad J` is replaced because it spent 99.16 ILS in the current run with no leads, and its lifetime CPL is weak at 73.55.
- `W 2605_1` uses no new material. It is a controlled reshuffle using the best available non-duplicated women-compatible media candidate plus a coherent calm/quiet-space headline and text.
- `W 2603_2` was not selected despite strong historical CPL because it duplicates the kept `Womens Ad A` media and text.

---

## Planned components for W 2605_1

| Component type | Component | Provenance / tags |
|---|---|---|
| Media | `Shihonage_MF_Dojo_Photo` | Attachment: `Shihonage_MF_Dojo_Photo__A.png`; tags: `Illustration - Photo Art`, `Instructional / Demonstration` |
| Headline | `מרחב שקט לעצמך` | Tags: `Stress / Mental Load`, `Calm Under Pressure`, `Affirmative` |
| Primary text | `Quiet Space - Bullet Calm` | Tags: `Stress / Mental Load`, `Calm Under Pressure`, `Checklist` |

Actual image content was inspected. The image shows calm paired dojo instruction with controlled hand/arm connection. It is compatible with the quiet-space and calm-under-pressure message.

---

## Constraints check

- **Assessed week:** 2026-W19.
- **Decision week:** 2026-W20.
- **Current contiguous runs:** evaluated separately from weekly and lifetime totals.
- **Intentional-run identification:** clear; four intended ads identified from `intended_run` and the previous decision log.
- **Creative uniqueness:** satisfied within both campaigns.
- **New-material constraint:** satisfied; zero new-material ads.
- **Media provenance:** satisfied. Referenced existing media appear in `attachments_manifest.json` and `attachments.tar`.
- **Image–text semantic check:** passed for all planned ads.
- **Gender/campaign integrity:** no blocking mismatch identified.

---

## What would change this decision next week

- If `Mens Ad N` receives meaningful spend and still produces no leads, replace it rather than carrying it on low-delivery grounds.
- If `Mens Ad J` continues to perform well, keep it as the men’s anchor.
- If `Womens Ad A` continues to perform well, preserve it and avoid duplicating its components.
- If `W 2605_1` fails with meaningful spend, the quiet/calm women’s reshuffle should cool, and the next women’s probe should move back toward competence/body-capability framing.

---

## Confidence level

Moderate-high.

The keep/replace decisions follow the explicit rules. Confidence is highest for keeping `Mens Ad J` and `Womens Ad A`, moderate for keeping `Mens Ad N` because it is a low-delivery keep, and moderate for `W 2605_1` because it is a controlled reshuffle with coherent image-text alignment but not a previously proven full ad.

---

End of Plan for 2026-W20

---


# Plan for 2026-W19 (assessing 2026-W18)

### Weeks

- **Assessed (data) week:** 2026-W18
- **Decision / planned week:** 2026-W19

### Ads active in assessed week (2026-W18)

- Men:

| Ad name   | Spend | CPL | Lifetime spend | Lifetime CPL |
| --------- | ----: | --: | -------------: | -----------: |
| Mens Ad J |  0.03 |   — |        1477.09 |        36.93 |
| M 2604_1  | 200.84 | 200.84 |       200.84 |       200.84 |

- Women:

| Ad name     | Spend |    CPL | Lifetime spend | Lifetime CPL |
| ----------- | ----: | -----: | -------------: | -----------: |
| Womens Ad A |  86.75 |  28.92 |        1303.56 |        40.74 |
| Womens Ad D | 118.67 | 118.67 |         913.38 |        57.09 |

### Ads planned for decision week (2026-W19)

- Men: Mens Ad J, Mens Ad N

#### Reuse:

| Name      | Spend | CPL | Lifetime spend | Lifetime CPL |
| --------- | ----: | --: | -------------: | -----------: |
| Mens Ad J |  0.03 |   — |        1477.09 |        36.93 |
| Mens Ad N |     — |   — |         260.91 |        52.18 |

#### Reshuffle:

None.

#### New content

None.

- Women: Womens Ad A, Womens Ad J

#### Reuse:

| Name        | Spend |   CPL | Lifetime spend | Lifetime CPL |
| ----------- | ----: | ----: | -------------: | -----------: |
| Womens Ad A | 86.75 | 28.92 |        1303.56 |        40.74 |
| Womens Ad J |     — |     — |         342.14 |        57.02 |

#### Reshuffle:

None.

#### New content

None.

---

## Portfolio decision

- **Men:** keep `Mens Ad J`; replace `M 2604_1` with `Mens Ad N`.
- **Women:** keep `Womens Ad A`; replace `Womens Ad D` with `Womens Ad J`.

---

## Rationale concise

- `Womens Ad A` is the only assessed-week clear winner: 86.75 ILS spend, 3 leads, CPL 28.92.
- `Mens Ad J` is retained because current-run spend is only 0.03 ILS and lifetime CPL remains strong at 36.93; the `2026-W18` result is non-delivery, not a creative failure.
- `M 2604_1` is replaced because it spent 200.84 ILS for one lead in its first run.
- `Womens Ad D` is replaced because it spent 118.67 ILS for one lead in its reintroduction.
- `Mens Ad N` is selected as an existing-material replacement: historically reasonable, not recently used, no duplicate men’s components, and visually compatible with the time-out/renewal framing.
- `Womens Ad J` is selected as an existing-material replacement: historically reasonable, not recently used, no duplicate women’s components, and visually compatible with the calm/strength/time-for-yourself framing.

---

## Constraints check

- **Assessed week:** `2026-W18`.
- **Decision week:** `2026-W19`.
- **Creative uniqueness:** satisfied within both campaigns.
- **New-material constraint:** satisfied; no new material introduced for `2026-W19`.
- **Media provenance:** planned media all exist in `attachments_manifest.json` and `attachments.tar`:
  - `Tenshinage_lineart_controlled`
  - `Outside_Sunset_MM_Kaitenage_photo`
  - `Dojo_Instruction_FemalePair`
  - `Illustrated_Calm_Poster_Female`
- **Image–text semantic check:** passed for all planned ads.
- **Gender/campaign integrity:** satisfied.
- **Data-hygiene note:** `ad_components.csv` omits headline IDs/text for active ads, but the headline assignments are reconstructable from `performance_data.json`.

---

## What would change this decision next week

- If `Mens Ad J` again receives near-zero spend, treat it as a delivery problem and consider replacing it despite strong lifetime CPL.
- If `Mens Ad N` receives meaningful spend and performs poorly, return to reshuffling stronger individual men’s components rather than reusing old full ads.
- If `Womens Ad A` remains strong, preserve it as the women’s campaign anchor.
- If `Womens Ad J` performs poorly, prefer a controlled reshuffle rather than returning immediately to `Womens Ad D`.

---

## Confidence level

Moderate.

The women’s decision is relatively high confidence because `Womens Ad A` is clearly strong and `Womens Ad D` clearly failed the weekly/run thresholds. The men’s decision is lower confidence because `Mens Ad J` did not receive real delivery, so the portfolio still depends partly on Meta delivery behavior rather than creative evidence.

---

End of Plan 2026-W19

---

# Plan for 2026-W18 (assessing 2026-W17)

### Weeks

* **Assessed (data) week:** 2026-W17
* **Decision / planned week:** 2026-W18

### Ads active in assessed week (2026-W17)

* Men:

| Ad name   |  Spend | CPL | Lifetime spend | Lifetime CPL |
| --------- | -----: | --: | -------------: | -----------: |
| Mens Ad B | 200.14 |   — |        1401.33 |        50.05 |
| Mens Ad J |   0.00 |   — |        1477.06 |        36.93 |

* Women:

| Ad name     |  Spend |   CPL | Lifetime spend | Lifetime CPL |
| ----------- | -----: | ----: | -------------: | -----------: |
| Womens Ad A | 124.95 | 31.24 |        1216.81 |        41.96 |
| W 2602_4    |  82.96 |     — |         190.39 |        95.20 |

### Ads planned for decision week (2026-W18)

* Men: Mens Ad J, M 2604_1

#### Reuse:

| Name      | Spend | CPL | Lifetime spend | Lifetime CPL |
| --------- | ----: | --: | -------------: | -----------: |
| Mens Ad J |  0.00 |   — |        1477.06 |        36.93 |

#### Reshuffle:

None.

#### New content

**M 2604_1**

| Component                            | Spend | CPL | Lifetime spend | Lifetime CPL |
| ------------------------------------ | ----: | --: | -------------: | -----------: |
| **Photo_Dojo_MM_HandContact_Static** |       |     |                |              |
| **שקט במצבי לחץ**                    |       |     |                |              |
| **Calm Under Pressure — Men**        |       |     |                |              |

**New media:** `Photo_Dojo_MM_HandContact_Static.png`

**New headline:** שקט במצבי לחץ

**New primary text:**

אנחנו מכירים את זה: כשלחץ עולה, הגוף מתכווץ.
באייקידו לומדים לעבוד אחרת.
למצוא שקט גם בתוך מצבי לחץ.

▫️ לשחרר מתח בלי לאבד יציבות
▫️ לנוע בביטחון בלי להישען על כוח
▫️ להגיב ברוגע גם ברגע של עימות

הדוג'ו בשכונה ג' בבאר שבע ידידותי ולא תחרותי. מתאים גם למתחילים.
לחץ על התמונה לשיעור ניסיון בלי התחייבות.

**Tags:**

* Media: `Media_Style = Photo - Dojo`; `Media_Energy = Instructional / Demonstration`; `Pairing = Male-Male`; `Mood = Calm / Controlled`

* Headline: `Hook = Problem-naming`; `Promise = Calm Under Pressure`; `Tone = Direct`

* Text: `Hook = Stability / Balance`; `Promise = Calm Under Pressure`; `Promise = Confidence / Self-Trust`; `Structure = Checklist`; `Gendered grammar = Male`; `Target = Men`

* Women: Womens Ad A, Womens Ad D

#### Reuse:

| Name        |  Spend |   CPL | Lifetime spend | Lifetime CPL |
| ----------- | -----: | ----: | -------------: | -----------: |
| Womens Ad A | 124.95 | 31.24 |        1216.81 |        41.96 |
| Womens Ad D |      — |     — |         794.71 |        52.98 |

#### Reshuffle:

None.

#### New content

None.

---

## Portfolio decision

* **Men:** keep `Mens Ad J`; replace `Mens Ad B` with `M 2604_1`, using new media plus new headline/text.
* **Women:** keep `Womens Ad A`; replace `W 2602_4` with the cooled existing full ad `Womens Ad D`.
* **New material:** exactly one planned ad contains new material, but that ad contains both new media and new text/headline by explicit human override.

---

## Rationale (concise)

* `Mens Ad B` failed the keep rules: no W17 leads, 200.14 ILS weekly spend, and current-run CPL 75.04.
* `Mens Ad J` received zero delivery, so it does not provide a negative creative signal; its lifetime CPL remains the strongest in the men’s campaign.
* A pure men’s reuse option was weak: `Mens Ad A` is not cooled enough as a full ad, and `Mens Ad N` recycles too much of the just-failed `Mens Ad B` component set.
* `M 2604_1` is a deliberate human override of the earlier controlled-variation recommendation: it introduces new media and new copy in one ad because the new photo is a strong semantic fit for the pressure/calm framing.
* `Womens Ad A` clearly met the keep rule with W17 CPL 31.24.
* `W 2602_4` failed the keep rules and should cool.
* `Womens Ad D` is a conservative, cooled, existing full-ad replacement that does not duplicate any `Womens Ad A` component.

---

## Constraints check

* Assessed week and decision week are explicitly separated.
* Current contiguous runs are not conflated with lifetime totals.
* Exactly four intended ads were identified in `2026-W17`; no intent ambiguity.
* No media, headline, or text is duplicated within the men’s planned campaign.
* No media, headline, or text is duplicated within the women’s planned campaign.
* Exactly one planned ad contains new material.
* The one new-material ad contains both new media and new headline/text by explicit human override.
* Existing media are traceable to `attachments_manifest.json` and `attachments.tar`:

  * `Tenshinage_lineart_controlled` → `Tenshinage_lineart_controlled.jpg`
  * `Dojo_Instruction_FemalePair` → `Dojo_Instruction_FemalePair.png`
  * `Swariwaza_Kokyuho_Dojo_Photo` → `Swariwaza_Kokyuho_Dojo_Photo.png`
* New media to add to the asset registry:

  * `Photo_Dojo_MM_HandContact_Static` → `Photo_Dojo_MM_HandContact_Static.png`
* Actual media content was inspected for image–text alignment.
* New tag values introduced / to confirm in tagging table: `Pairing = Male-Male`; `Mood = Calm / Controlled`. If these dimensions are not retained, describe the same information in notes rather than formal tags.

---

## Data hygiene / learning notes

* `ad_components.csv` did not expose headline text correctly; headline mapping was reconstructed from `performance_data.json` through the Ads → Creatives → Headlines relationship.
* Mens Ad J’s W17 zero-delivery should be watched. If it again receives no spend in W18, treat it as a delivery problem requiring a stronger replacement, not as a creative-performance datapoint.
* `Photo_Dojo_MF_Ikkyo_Static` now has enough negative evidence to stop using it immediately.
* Because `M 2604_1` introduces both new media and new copy, W18 will not allow clean attribution if the ad performs unusually well or poorly.

---

## What would change this decision next week

* If `Mens Ad J` again receives near-zero delivery, replace it even if its lifetime CPL remains strong.
* If `M 2604_1` spends meaningfully with no leads, do not infer whether the failure came from media or copy alone; treat the whole new combination cautiously.
* If `Womens Ad D` underperforms but `Womens Ad A` remains strong, exploit women’s existing materials around the `Dojo_Instruction_FemalePair` / competence axis once component uniqueness allows it.
* If both women’s ads underperform, deprioritize calm/time-out framing and return to body competence / meaningful movement.

---

## Confidence level

Moderate.

The keep/replace decisions are high confidence because they follow the explicit rules. The exact men’s replacement is lower confidence because it introduces both new media and new copy in the same ad. The image and text are semantically well aligned, but the combined novelty reduces interpretability.

---

End of Plan 2026-W18

---


# Plan for 2026-W16 (assessing 2026-W15)

### Weeks

* **Assessed (data) week:** 2026-W15
* **Decision / planned week:** 2026-W16

### Ads active in assessed week (2026-W15)

* Men:

| Ad name   |  Spend |   CPL | Lifetime spend | Lifetime CPL |
| --------- | -----: | ----: | -------------: | -----------: |
| Mens Ad A |  75.05 |     — |        1147.17 |        45.89 |
| Mens Ad B | 131.57 | 43.86 |        1082.66 |        43.31 |

* Women:

| Ad name     |  Spend |   CPL | Lifetime spend | Lifetime CPL |
| ----------- | -----: | ----: | -------------: | -----------: |
| Womens Ad P |  88.22 | 44.11 |         722.91 |        51.64 |
| W 2603_4    | 116.29 | 58.15 |         237.67 |        59.42 |

### Ads planned for decision week (2026-W16)

* Men:

#### Reuse:

| Name      |  Spend |   CPL | Lifetime spend | Lifetime CPL |
| --------- | -----: | ----: | -------------: | -----------: |
| Mens Ad A |  75.05 |     — |        1147.17 |        45.89 |
| Mens Ad B | 131.57 | 43.86 |        1082.66 |        43.31 |

#### Reshuffle:

None.

#### New content

None.

* Women:

#### Reuse:

| Name        | Spend |   CPL | Lifetime spend | Lifetime CPL |
| ----------- | ----: | ----: | -------------: | -----------: |
| Womens Ad P | 88.22 | 44.11 |         722.91 |        51.64 |

#### Reshuffle:

**W 2604_1**

| Component                      | Spend | CPL | Lifetime spend | Lifetime CPL |
| ------------------------------ | ----: | --: | -------------: | -----------: |
| Illustrated_Calm_Poster_Female |     — |   — |         773.06 |        70.28 |
| גוף חזק, ראש רגוע              |     — |   — |         855.23 |        38.87 |
| Meaningful Movement            |     — |   — |         855.23 |        38.87 |

#### New content

None.

---

## Portfolio decision

* **Men:** keep both current ads.
* **Women:** keep **Womens Ad P** and replace **W 2603_4** with one exploitive reshuffle from existing materials.
* **New material:** none for `2026-W17`.

---

## Rationale (concise)

1. **Keep the ads that meet the written rules.**

   * **Mens Ad B** and **Womens Ad P** both met the weekly CPL threshold.
   * **Mens Ad A** failed on leads but still qualifies under the run-spend fallback because its current run spend is below 80 ILS.

2. **Do not protect W 2603_4.**

   * Weekly CPL is above 50.
   * Current run spend is above 80.
   * Current run CPL is also above 30.

3. **Exploit strong women components rather than introduce novelty.**

   * The best women’s headline and text components remain **גוף חזק, ראש רגוע** and **Meaningful Movement**.
   * The strongest women’s media asset is already occupied by **Womens Ad P**, so the replacement must exploit around that constraint.

4. **Avoid duplication and weak recent clusters.**

   * Do not duplicate any component already used by **Womens Ad P**.
   * Do not continue leaning on the weak recent **Swariwaza + Time Out For You (Mom)** cluster.

---

## Constraints check

* Assessed week and decision week are explicitly separated.
* No media, headline, or text is duplicated within either campaign for `2026-W17`.
* New-material constraint is satisfied: **0 new ads**.
* The women’s replacement uses only existing materials.
* The women’s reshuffle is a new combination rather than a repeated historical combo.
* No new tags are introduced.

---

## Data hygiene / learning notes

* Current-run summaries are clean this week: each active ad has a one-week current run, which matches the prior portfolio change.
* No intent ambiguity was present in the assessed week: exactly four intended ads were active.

---

## What would change this decision next week

* If **Mens Ad A** fails again on normal spend, stop treating this as a low-evidence hold.
* If **Mens Ad B** holds this level of efficiency for another week, it becomes the clear men’s anchor again.
* If **Womens Ad P** weakens materially while the reshuffle also fails, the women’s side will need a broader rebuild rather than a one-slot replacement.
* If **W 2604_1** underdelivers despite normal spend, shift away from calm illustrative women media and back toward other proven structures.

---

## Confidence level

**Moderate.**

The keep/replace logic is straightforward. The main uncertainty is not the threshold logic; it is the week-label jump and the fact that the replacement must work around the already-occupied strongest women’s media asset.

---

End of Plan for 2026-W16

---

# Plan for 2026-W15 (assessing 2026-W14)

### Weeks

* **Assessed (data) week:** 2026-W14
* **Decision / planned week:** 2026-W15

### Ads active in assessed week (2026-W14)

* Men:

| Ad name   |  Spend |   CPL | Lifetime spend | Lifetime CPL |
| --------- | -----: | ----: | -------------: | -----------: |
| Mens Ad A |  91.29 | 45.65 |        1072.12 |        42.88 |
| M 2603_3  | 102.42 | 51.21 |         148.29 |        74.14 |

* Women:

| Ad name     |  Spend |   CPL | Lifetime spend | Lifetime CPL |
| ----------- | -----: | ----: | -------------: | -----------: |
| Womens Ad P | 139.79 | 46.60 |         634.69 |        52.89 |
| W 2603_4    |  61.69 | 30.84 |         121.38 |        60.69 |

### Ads planned for decision week (2026-W15)

* Men:

#### Reuse:

| Name      | Spend |   CPL | Lifetime spend | Lifetime CPL |
| --------- | ----: | ----: | -------------: | -----------: |
| Mens Ad A | 91.29 | 45.65 |        1072.12 |        42.88 |
| Mens Ad B |     — |     — |         951.09 |        43.23 |

#### Reshuffle:

None.

#### New content

None.

* Women:

#### Reuse:

| Name        |  Spend |   CPL | Lifetime spend | Lifetime CPL |
| ----------- | -----: | ----: | -------------: | -----------: |
| Womens Ad P | 139.79 | 46.60 |         634.69 |        52.89 |
| W 2603_4    |  61.69 | 30.84 |         121.38 |        60.69 |

#### Reshuffle:

None.

#### New content

None.

---

## Portfolio decision

* **Men:** keep `Mens Ad A`; replace `M 2603_3` with the cooled historical winner `Mens Ad B`.
* **Women:** keep both current ads.
* **New material:** none for `2026-W15`.

---

## Catch-up note

One weekly decision cycle was skipped.

The portfolio decided for `2026-W13` remained active across **two completed data weeks**: `2026-W13` and `2026-W14`.

This entry therefore uses:

* `2026-W14` as the **formal assessed week**
* `2026-W15` as the **decision / planned week**
* explicit interpretation from:

  * `2026-W13` on its own
  * `2026-W14` on its own
  * the combined `2026-W13` + `2026-W14` hold period

No separate formal entry is written for the skipped cycle.

---

## Rationale (concise)

1. **Use the latest week formally, but do not ignore the hold-period context.**

   * `2026-W13` was highly unstable.
   * `2026-W14` sharply reversed it.

2. **Keep ads that met the latest-week keep rule.**

   * `Mens Ad A`, `Womens Ad P`, and `W 2603_4` all had latest-week CPLs below 50.

3. **Do not protect `M 2603_3`.**

   * It improved in `2026-W14`, but still missed the keep threshold.
   * Its current-run CPL and lifetime CPL are both weak.
   * Its evidence base is too small to justify another hold week.

4. **Exploit the cleanest cooled men’s winner.**

   * `Mens Ad B` is historically strong, inactive long enough, and component-distinct from `Mens Ad A`.

5. **Avoid novelty when exploitation is available.**

   * No new material is needed for `2026-W15`.

---

## Constraints check

* Latest completed week and planned week are explicitly separated.
* This is treated as **one catch-up decision**, not two normal weekly cycles.
* No media, headline, or text is duplicated within the men’s campaign for `2026-W15`.
* No media, headline, or text is duplicated within the women’s campaign for `2026-W15`.
* New-material constraint is satisfied: **0 new ads**.
* `Mens Ad B` satisfies the six-week cooling requirement.
* Planned reused media were checked against actual image content, not tags alone.

---

## Data hygiene / learning notes

* The exported weekly summary CSVs appear stale through `2026-W12`, while raw `Weekly_runs` data and lifetime exports extend to `2026-W14`.
* This catch-up interpretation therefore relied on the fresher raw rows plus lifetime tables.
* Small non-intended residual rows in `2026-W13` were excluded from intent-level evaluation:

  * `M 2603_1` — 3.80 ILS
  * `M 2603_2` — 3.95 ILS
  * `W 2603_3` — 5.37 ILS
* The historical campaign-label inconsistency around `M 2603_2` remains present in the raw data.

---

## What would change this decision next week

* If `Womens Ad P` posts another expensive zero-lead week at meaningful spend, treat the `2026-W14` recovery as noise rather than rebound.
* If `W 2603_4` fails again on normal delivery, stop protecting it on low evidence.
* If `Mens Ad B` underdelivers despite normal spend, move back toward either deeper men’s baselines or a controlled reshuffle.
* If summary exports remain stale relative to raw tables, continue to trust raw rows over lagging rollups.

---

## Confidence level

**Moderate.**

The week structure is clear and the catch-up framing is valid. The main uncertainty is not the portfolio logic; it is the volatility across the two held weeks and the freshness mismatch between stale summary exports and fresher raw rows.

---

End of Plan for 2026-W15

---

# Plan for 2026-W13 (assessing 2026-W12)

### Weeks

* **Assessed (data) week:** 2026-W12
* **Decision / planned week:** 2026-W13

### Ads active in assessed week (2026-W12)

* Men:

| Ad name  | Spend | CPL | Lifetime spend | Lifetime CPL |
| -------- | ----: | --: | -------------: | -----------: |
| M 2603_1 | 64.57 |   — |         253.49 |        63.37 |

* Women:

| Ad name     |  Spend |    CPL | Lifetime spend | Lifetime CPL |
| ----------- | -----: | -----: | -------------: | -----------: |
| Womens Ad P | 185.02 |  37.00 |         352.95 |        39.22 |
| M 2603_2    | 131.34 | 131.34 |         139.81 |       139.81 |

**Data-hygiene note:** `W 2603_3` also appeared in `2026-W12` with `campaign = 0`, missing components, and only `9.00` ILS spend. I am treating it as a stray invalid record rather than a stable campaign asset.

### Ads planned for decision week (2026-W13)

* Men:

#### Reuse

| Name      | Spend | CPL | Lifetime spend | Lifetime CPL |
| --------- | ----: | --: | -------------: | -----------: |
| Mens Ad A |     — |   — |         825.09 |        39.29 |

#### Reshuffle

**M 2603_3**

| Component                         | Spend | CPL | Lifetime spend | Lifetime CPL |
| --------------------------------- | ----: | --: | -------------: | -----------: |
| Outside_Sunset_MM_Kaitenage_photo |     — |   — |        1087.31 |        41.82 |
| ללמוד לשלוט ברגע                  |     — |   — |         880.60 |        40.03 |
| Stable Without Struggle           |     — |   — |         432.89 |        54.11 |

#### New content

None.

* Women:

#### Keep / Reuse

| Name        |  Spend |   CPL | Lifetime spend | Lifetime CPL |
| ----------- | -----: | ----: | -------------: | -----------: |
| Womens Ad P | 185.02 | 37.00 |         352.95 |        39.22 |

#### Reshuffle

**W 2603_4**

| Component                    | Spend | CPL | Lifetime spend | Lifetime CPL |
| ---------------------------- | ----: | --: | -------------: | -----------: |
| Swariwaza_Kokyuho_Dojo_Photo |     — |   — |         952.78 |        63.52 |
| גוף חזק, ראש רגוע            |     — |   — |         855.23 |        38.87 |
| Time Out For You (Mom)       |     — |   — |        1386.80 |        57.78 |

#### New content

None.

---

## Portfolio decision

* **Men:** replace the weak current run with one cooled historical winner and one high-evidence reshuffle.
* **Women:** keep the only clear weekly winner and pair it with a conservative exploitative reshuffle rather than novelty.

---

## Rationale (concise)

1. **Exploit historical winners first.**

   * There is no shortage of proven ads and components.
2. **Do not protect weak probes once they have enough spend to fail.**

   * `M 2603_2` is past that point.
3. **Do not overreact to malformed records.**

   * `W 2603_3` is treated as a data-hygiene issue, not as a learning asset.
4. **Keep the one clean success.**

   * `Womens Ad P` earned that status this week.

---

## Data hygiene / learning notes

* Bring `decision_log.md` back into sync next week; it currently lags the data.
* Fix the campaign assignment for `M 2603_2` in the source system if it is truly a men's ad.
* Investigate why the headline `"משהו חדש לגוף ולראש"` is missing from the headline lifetime export.
* Confirm whether `W 2603_3` is a test placeholder, a failed draft, or a bad export row.

---

## What would change this decision next week

* If **Womens Ad P** falls sharply while its spend remains meaningful, I would stop treating it as an anchor.
* If the **M 2603_3** reshuffle under-delivers despite normal spend, I would revert harder toward the deepest men's baselines.
* If the women reshuffle underperforms while **Womens Ad P** remains strong, I would next test another strong women baseline rather than introduce new content.
* If source-data hygiene remains messy, I would reduce confidence in component-level learning and lean more on ad-level winners.

---

## Confidence level

**Moderately high.**

The main portfolio choices are straightforward. The main uncertainty is not the creative logic; it is the recent metadata quality.

---

End of Plan 2026-W13

---


# Plan for 2026-W12 (assessing 2026-W11)

### Weeks

- **Assessed (data) week:** 2026-W11
- **Decision / planned week:** 2026-W12

### Ads active in assessed week (2026-W11)

- Men:

| Ad name | Spend | CPL | Lifetime spend | Lifetime CPL |
|---|---:|---:|---:|---:|
| M 2603_1 | 188.92 | 47.23 | 188.92 | 47.23 |
| M 2603_2 | 8.47 | — | 8.47 | — |

- Women:

| Ad name | Spend | CPL | Lifetime spend | Lifetime CPL |
|---|---:|---:|---:|---:|
| W 2603_1 | 198.61 | 66.20 | 288.60 | 57.72 |
| W 2603_2 | 0.00 | — | 98.24 | 32.75 |

### Ads planned for decision week (2026-W12)

- Men:

#### Reuse:

None.

#### Reshuffle:

None.

#### Keep as-is:

| Name | Weekly spend | Weekly CPL | Run spend | Run CPL | Lifetime spend | Lifetime CPL |
|---|---:|---:|---:|---:|---:|---:|
| M 2603_1 | 188.92 | 47.23 | 188.92 | 47.23 | 188.92 | 47.23 |
| M 2603_2 | 8.47 | — | 8.47 | — | 8.47 | — |

- Women:

#### Reuse:

| Name | Spend | CPL | Lifetime spend | Lifetime CPL |
|---|---:|---:|---:|---:|
| Womens Ad P | 167.93 | 41.98 | 167.93 | 41.98 |

#### Reshuffle:

**W 2603_3**

| Component | Spend | CPL | Lifetime spend | Lifetime CPL |
|---|---:|---:|---:|---:|
| Shihonage_MF_Dojo_Photo | 824.41 | 39.26 | 824.41 | 39.26 |
| גוף חזק, ראש רגוע | 855.23 | 38.87 | 855.23 | 38.87 |
| Meaningful Movement | 855.23 | 38.87 | 855.23 | 38.87 |

#### New material:

None.

---

## Portfolio decision

- **Men:** keep both current ads.
- **Women:** replace both current ads.
- **New material:** none for 2026-W12.

---

## Rationale

- `M 2603_1` met the primary keep rule in its first meaningful week.
- `M 2603_2` received too little spend to justify replacement.
- `W 2603_1` failed the keep rules after scaling and now appears, from the corrected mapping, to be a weak component combination rather than a pure component failure.
- `W 2603_2` had acceptable run CPL but received zero spend in 2026-W11; under the written rules it is still a replacement, though confidence in the interpretation remains limited.
- The women’s campaign still has enough historical strength to rebuild from existing winners rather than introducing new material.

---

## Constraints check

- Latest completed data week and planned week are explicitly separated.
- No media, headline, or text is repeated within the women’s campaign for 2026-W12.
- At most one ad may contain new material; 2026-W12 contains none.
- The reused ad (`Womens Ad P`) satisfies the six-week cooling rule.
- `W 2603_3` is a new combination of existing materials rather than a repeated historical combination.
- Planned women’s ads were checked against actual image content, not tags alone.

---

## Data hygiene / learning notes

- `ad_components.csv` corrected the current component mappings and materially improved interpretability.
- `M 2603_2` is mislabeled as women’s in component-level exports; campaign identity had to be recovered from the ad name and weekly context.
- `Dojo_Instruction_FemalePair` and `Dynamic_Throw_FF_LineArt` are duplicate image files under different names.
- `Illustrated_Soft_Strength_Female` appears mis-tagged as `Photo - Dojo`.
- Delivery concentration remains a confound: low-spend ads should not be over-interpreted.

---

## What would change this decision next week

- If `M 2603_2` again receives very low spend, it should stop being protected by the low-delivery rule.
- If the rebuilt women’s portfolio again fails despite higher-delivery proven inventory, the next step should be a deliberately designed **new media** probe.
- If `Womens Ad P` underperforms materially on re-entry, confidence in old women’s winners should be downgraded.

---

## Confidence level

- **Men keep decisions:** high.
- **Women replacement decisions:** medium.
- **Interpretation of `W 2603_2`:** low-to-medium because zero delivery makes the signal ambiguous.

---

End of Plan for 2026-W12

---

# Plan for 2026-W11 (assessing 2026-W10)

### Weeks

- **Assessed (data) week:** 2026-W10
- **Decision / planned week:** 2026-W11

### Ads active in assessed week (2026-W10)

- Men:

| Ad name | Spend | CPL | Lifetime spend | Lifetime CPL |
|---|---:|---:|---:|---:|
| Mens Ad J | 0.00 | — | 1477.06 | 36.93 |
| M 2602_1 | 195.38 | 97.69 | 285.32 | 71.33 |

- Women:

| Ad name | Spend | CPL | Lifetime spend | Lifetime CPL |
|---|---:|---:|---:|---:|
| W 2603_1 | 89.99 | 45.00 | 89.99 | 45.00 |
| W 2603_2 | 98.24 | 32.75 | 98.24 | 32.75 |

### Ads planned for decision week (2026-W11)

- Men:

#### Reuse:

None.

#### Reshuffle:

**M 2603_1 (proposed)**

| Component | Spend | CPL | Lifetime spend | Lifetime CPL |
|---|---:|---:|---:|---:|
| Shihonage_MF_Dojo_Photo | 824.41 | 39.26 | 824.41 | 39.26 |
| לנער את השגרה | 1492.07 | 48.13 | 1492.07 | 48.13 |
| Time Out For You (Dad) | 1087.31 | 41.82 | 1087.31 | 41.82 |

**M 2603_2 (proposed)**

| Component | Spend | CPL | Lifetime spend | Lifetime CPL |
|---|---:|---:|---:|---:|
| Outside_Sunset_MM_Kaitenage_photo | 1087.31 | 41.82 | 1087.31 | 41.82 |
| ללמוד לשלוט ברגע | 880.60 | 40.03 | 880.60 | 40.03 |
| Everyday Pressure | 824.41 | 39.26 | 824.41 | 39.26 |

- Women:

#### Reuse:

| Name | Spend | CPL | Lifetime spend | Lifetime CPL |
|---|---:|---:|---:|---:|
| W 2603_1 | 89.99 | 45.00 | 89.99 | 45.00 |
| W 2603_2 | 98.24 | 32.75 | 98.24 | 32.75 |

---

## Portfolio decision
---

# Plan for 2026-W10 (assessing 2026-W09)

### Weeks

* **Assessed (data) week:** 2026-W09
* **Decision / planned week:** 2026-W10

### Ads active in assessed week (2026-W09)

* Men: Mens Ad J, M 2602_1
* Women: W 2602_4, W 2026-W06 2

**Incidental delivery (not intentionally run):**

* Womens Ad A

### Ads planned for decision week (2026-W10)

* Men: Mens Ad J, M 2602_1
* Women: W2603_1, W2603_2

---

## Performance Summary (2026-W09)

### Men

**Mens Ad J**

* Weekly CPL ≈ 35.7
* Run CPL ≈ 32.6
* Lifetime CPL ≈ 36.9

Clear success signal.

---

**M 2602_1**

* Weekly CPL ≈ 45
* 2 leads during first week of delivery.

Early probe with acceptable CPL.

---

### Women

**W 2602_4**

* Weekly CPL ≈ 52
* Run spend ≈ 104

Failed primary keep rule (weekly CPL < 50).
Also failed fallback rule (run spend > 80 with CPL > 30).

---

**W 2026-W06 2**

* Spend ≈ 64
* Leads = 0

Originally retained under the “insufficient delivery” rule (spend < 80).
However, overall campaign signal remained weak.

---

**Womens Ad A**

* Spend ≈ 25
* Leads = 1

This ad was **not intentionally run** and had already been rejected in the previous week.
Delivery occurred due to Facebook serving residual impressions.

Decision: **exclude from evaluation**.

---

## Keep Decisions

### Men

* **Mens Ad J retained**

  * Meets primary rule: weekly CPL < 50.

* **M 2602_1 retained**

  * Early probe with acceptable CPL.

---

## Replacement Decisions

### Women

Initial algorithmic recommendation:

* Replace **W 2602_4**
* Retain **W 2026-W06 2** due to insufficient delivery.

However, during review the following reasoning was applied:

1. The women’s campaign has not produced a stable performer.
2. Both ads lacked convincing signal.
3. Replacing both ads accelerates exploration.

Decision:

* **Replace both W 2602_4 and W 2026-W06 2.**

This creates a **full refresh week for the women’s campaign**.

---

## New Ads

### W2603_1

Media
Shihonage_MF_Dojo_Photo__A

Headline
לנער את השגרה

Text
Quiet Space – Bullet Calm

#### Component status

Media: previously used, historically strong (reshuffle)
Headline: previously used, historically strong (reshuffle)
Text: exploratory component (low historical spend)

#### Rationale

This ad combines two historically strong components with a new text variant.

Design goal:

* high-probability engagement hook
* introduce a calmer text concept to probe messaging tone

Conceptual frame:

“shake the routine” + dojo action imagery + calm internal experience.

---

### W2603_2

Media
Dojo_Instruction_FemalePair

Headline
משהו חדש לגוף ולראש

Text
Posture / shoulder strengthening copy (same text previously used in Womens Ad A)

#### Component status

Media: existing component (reshuffle)
Headline: new combination in this context
Text: previously used text component (reshuffle)

#### Rationale

This ad intentionally probes a **different conceptual entry point** from W2603_1.

Frame:

* instruction
* guided learning
* body awareness

The media shows instructor interaction, so the headline emphasizing learning and discovery was chosen to align visually and semantically.

---

## Component Strategy

Two distinct creative hypotheses are being tested:

### Ad W2603_1

Action / emotional reset frame

* dynamic technique image
* “shake up routine” headline
* calm experiential text

---

### Ad W2603_2

Instruction / learning frame

* instructor-student interaction image
* learning-oriented headline
* posture / strengthening message

This structure improves interpretability of results by testing **two clear messaging directions**.

---

## Naming Decisions

New ads named:

W2603_1
W2603_2

Format chosen:

W + YYMM + variant

Example:

W2603_1

Reasons:

* consistent with existing names (e.g., M 2602_1, W 2602_4)
* chronological lexical sorting
* avoids schema drift

Alternative format `W26_03_1` was considered but rejected due to unnecessary complexity.

---

## Deviations from Assistant Recommendations

During planning several recommendations were revised.

### 1. Replacement scope

Assistant recommendation:

* replace only W 2602_4

Final decision:

* replace **both women’s ads**

Reason:

* accelerate exploration due to weak signal.

---

### 2. Ad component pairing

One assistant-proposed combination contained a text that did not exist in the component table.

This was corrected by:

* reusing verified text from Womens Ad A
* selecting a headline consistent with the instructional media.

---

## Operational Notes

Incidental delivery of previously rejected ads occurred (Womens Ad A).

For future analysis cycles it may be useful to apply a heuristic:

Ignore ads with **spend < 30 ILS unless intentionally run**.

This prevents accidental delivery from influencing weekly evaluation.

---

End of Plan for 2026-W10

---


# Plan for 2026-W09 (assessing 2026-W08)

### Weeks

- **Assessed (data) week:** 2026-W08
- **Decision / planned week:** 2026-W09

### Ads active in assessed week (2026-W08)

- Men: Mens Ad B, Mens Ad J
- Women: Womens Ad A, W 2026-W06 1

### Ads planned for decision week (2026-W09)

- Men: Mens Ad J, M 2602_1
- Women: W 2026-W06 1, W 2602_4

---

## Performance Summary (2026-W08)

- Mens Ad J: Weekly CPL below 50 → retained under primary keep rule.
- Mens Ad B: ~70 ILS spend, 0 leads → failed weekly test and did not justify continued delivery.
- W 2026-W06 1: Minimal spend, no meaningful signal → retained due to insufficient delivery.
- Womens Ad A: CPL ≈ 105 → clear underperformance.

---

## Keep Decisions

- Mens Ad J retained (weekly CPL < 50).
- W 2026-W06 1 retained (low spend; no conclusive signal).

---

## Replacement Decisions

### Men

- Mens Ad B replaced.
- New ad: M 2602_1.
  - Text: Everyday Pressure (masculine grammar).
  - Rationale: 
    - Exploit historically strong text component (<50 lifetime CPL) 
    - New combination. 
    - Avoid reuse of cooled components.

### Women

- Womens Ad A replaced.
   - Reshuffle not viable due to:
     - 3‑month full-ad cooling rule.
     - 1‑week component cooling.
     - Only one female-coded media under 50 CPL, currently active in W 2026-W06 1.
    - Therefore, new-media slot used.
  - New ad: W 2602_4.
    - Headline: לנער את השגרה.
    - Text: Everyday Pressure (feminine grammatical variant).
    - Media: Photo_Dojo_MF_Ikkyo_Static.
      - New media
      - Rationale: 
        - Maintain disciplined component threshold (<50 lifetime CPL for headline and text
        - Accept constraint-driven media probe.

---

## Rule Updates

- Implemented 3-month cooling period for full ads before reuse.
- Implemented 1-week cooling period for components of replaced ads.
- Maintained strict <50 CPL threshold for component exploitation.

---

## Strategic Notes

- Constrained by thin high-performing media pool.
  - Future priority: collect additional female-forward, dynamic images to expand eligible reshuffle space.

---

End of Plan for 2026-W09

---

# Plan for 2026-W08 (assessing 2026-W07)

### Weeks

* **Assessed (data) week:** 2026-W07
* **Decision / planned week:** 2026-W08

### Ads active in assessed week (2026-W07)

* **Men:** Mens Ad J, Mens Ad O
* **Women:** W 2026-W06 2, W 2602_3

### Ads planned for decision week (2026-W08)

* **Men:** Mens Ad J, Mens Ad B
* **Women:** W 2026-W06 2, Womens Ad A

---

## Performance notes from 2026-W07

* Mens Ad J: weekly CPL **39.55** (2 leads on 79.11 spend) — still the anchor, but delivery dropped vs 2026-W06.
* Mens Ad O: weekly CPL **112.18** (1 lead on 112.18 spend); run CPL **127.47** at run spend **127.47** → fails keep rules.
* W 2026-W06 2: weekly CPL **46.94** (1 lead on 46.94 spend) → keep (low sample).
* W 2602_3: weekly CPL **70.05** (2 leads on 140.09 spend) → replace per keep rules.

---

## Portfolio decision

* **Men:** Keep Mens Ad J; replace Mens Ad O with **Mens Ad B** (historical performer, inactive ≥6 weeks).
* **Women:** Keep W 2026-W06 2; replace W 2602_3 with **Womens Ad A** (strongest historical performer, inactive ≥6 weeks).

---

## Rationale (priority order)

1. **Exploit historical winners**

   * Mens Ad B has meaningful lifetime delivery (spend **880.60**, CPL **40.03**) and is eligible for reuse.
   * Womens Ad A is the top Women historical asset in the dataset (spend **855.23**, CPL **38.87**) and is eligible for reuse.
2. **Probe uncertainty**

   * Deferred this week; first stabilize portfolios with high-evidence winners.
3. **Stabilize and interpret**

   * Using reused ads reduces variance from new combinations and keeps interpretation cleaner.

---

## Constraints check

* **New-material constraint:** satisfied (0/1 new ads).
* **Creative uniqueness per campaign:** satisfied (no media/headline/text duplicated within Men; none duplicated within Women).
* **Media provenance:** all media are present in `attachments_manifest.json` and stored in `attachments.tar` under their canonical names.
* **Image–text semantic check:** passed (manual inspection of the planned media vs headline/text).

---

End of Plan for 2026-W08

---

# Plan for 2026-W07 (assessing 2026-W06)

### Weeks

* **Assessed (data) week:** 2026-W06
* **Decision / planned week:** 2026-W07

---

### Ads active in assessed week (2026-W06)

* Men:

| Ad name   | Spend | CPL | Lifetime spend | Lifetime CPL |
| --------- | ----- | --- | -------------- | ------------ |
| Mens Ad J |       |     |                |              |
| Mens Ad O |       |     |                |              |

* Women:

| Ad name      | Spend | CPL | Lifetime spend | Lifetime CPL |
| ------------ | ----- | --- | -------------- | ------------ |
| W 2026-W06 1 |       |     |                |              |
| W 2026-W06 2 |       |     |                |              |

---

### Ads planned for decision week (2026-W07)

* Men:

#### Reuse:

| Name      | Spend | CPL | Lifetime spend | Lifetime CPL |
| --------- | ----- | --- | -------------- | ------------ |
| Mens Ad J |       |     |                |              |
| Mens Ad O |       |     |                |              |

* Women:

#### Reuse:

| Name         | Spend | CPL | Lifetime spend | Lifetime CPL |
| ------------ | ----- | --- | -------------- | ------------ |
| W 2026-W06 2 |       |     |                |              |

#### Reshuffle:

**W 2026-W06 3 – Shihonage Reshuffle**

| Component                | Spend | CPL | Lifetime spend | Lifetime CPL |
| ------------------------ | ----- | --- | -------------- | ------------ |
| Shihonage_MF_Dojo_Photo  |       |     |                |              |
| עוצמה, איזון, בטחון עצמי |       |     |                |              |
| Balance, Not Struggle    |       |     |                |              |

---

## Portfolio decision

* Men campaign remains stable with two proven performers.
* Women campaign retains the stronger of the two previous-week ads.
* The underperforming Women ad is replaced with a reshuffle anchored on a top-tier media asset (Shihonage_MF_Dojo_Photo).

---

## Rationale (concise)

* Shihonage_MF_Dojo_Photo is a statistically meaningful asset (≈1000 ILS lifetime spend, CPL ≈43).
* Headline 7 (עוצמה, איזון, בטחון עצמי) is an existing, proven headline.
* Balance, Not Struggle is among the stronger eligible texts.
* The combination has not previously been run together.
* No component duplication within Women this week.
* No reuse of components from the removed ad.

---

## Constraints check

* Week labels explicit and aligned.
* No component duplication within Women campaign.
* No reuse of removed ad components.
* No new material introduced.
* Gender designation respected.

---

End of Plan 2026-W07

---


# Plan for 2026-W06 (assessing 2026-W05)

### Weeks

* **Assessed (data) week:** 2026-W05
* **Decision / planned week:** 2026-W06

### Ads active in assessed week (2026-W05)

* **Men:** Mens Ad J, Mens Ad O, Mens Ad N

| Ad name   |  Spend |   CPL | Lifetime spend | Lifetime CPL |
| --------- | -----: | ----: | -------------: | -----------: |
| Mens Ad J | 181.32 | 25.90 |         762.74 |        40.14 |
| Mens Ad O |  13.47 |     — |          13.47 |            — |
| Mens Ad N |   0.16 |     — |         260.91 |        52.18 |

* **Women:** Womens Ad P, Womens Ad Q, Womens Ad R

| Ad name     | Spend |   CPL | Lifetime spend | Lifetime CPL |
| ----------- | ----: | ----: | -------------: | -----------: |
| Womens Ad P | 81.38 | 81.38 |         167.93 |        41.98 |
| Womens Ad Q | 18.56 |     — |         142.64 |        71.32 |
| Womens Ad R | 96.91 | 96.91 |          96.91 |        96.91 |

### Ads planned for decision week (2026-W06)

* **Men:** Mens Ad J, Mens Ad O

#### Reuse:

| Name      |  Spend |   CPL | Lifetime spend | Lifetime CPL |
| --------- | -----: | ----: | -------------: | -----------: |
| Mens Ad J | 329.85 | 29.99 |         762.74 |        40.14 |
| Mens Ad O |  13.47 |     — |          13.47 |            — |

* **Women:** W 2026-W06 1, W 2026-W06 2

#### Reshuffle:

**W 2026-W06 1**

| Component                   | Spend | CPL | Lifetime spend | Lifetime CPL |
| --------------------------- | ----: | --: | -------------: | -----------: |
| Dojo_Instruction_FemalePair |  1040 |  41 |           1040 |           41 |
| גוף חזק, ראש רגוע           |   855 |  39 |            855 |           39 |
| Meaningful Movement         |   855 |  38 |            855 |           38 |

**W 2026-W06 2**

| Component                   | Spend | CPL | Lifetime spend | Lifetime CPL |
| --------------------------- | ----: | --: | -------------: | -----------: |
| Outside_Sunset_MM_Kaitenage |  1087 |  41 |           1087 |           41 |
| ללמוד לשלוט ברגע            |   880 |  40 |            880 |           40 |
| Time Out For You            |  1087 |  41 |           1087 |           41 |

---

## Portfolio decision

* None of the women ads active in 2026-W05 met keep criteria; both women slots are replaced.
* Replacement strategy prioritizes **exploitation of historical winners at the component level**.
* Two women ads are constructed as reshuffles using only components with strong lifetime performance.

---

## Rationale (concise)

* Multiple women media, headlines, and texts show CPL ≈ 38–41 at meaningful spend and are treated as reliable exploit anchors.
* Recent week-level volatility does not override lifetime evidence.
* Each planned women ad is anchored on a distinct high-performing media asset, with supporting headline and text chosen from other proven components. Gender alignment was enforced at the text level.

---

## Constraints check

* Creative uniqueness per week: **satisfied** (no component reused across ads).
* New-material constraint: **satisfied** (no new media, headline, or text).
* Decision priority order: **satisfied** (exploit > probe > interpret).

---

## What would change this decision next week

* If exploit-based women ads fail to produce leads or show CPL ≥ 50 at meaningful spend, consider uncertainty probes using low-spend components.

---

## Confidence level

* **Men:** high
* **Women:** medium–high

---

End of Plan 2026-W06

---


# Plan for 2026-W05 (assessing 2026-W04)

### Weeks

* **Assessed (data) week:** 2026-W04
* **Decision / planned week:** 2026-W05

### Ads active in assessed week (2026-W04)

* Men: Mens Ad J, Mens Ad N
* Women: Womens Ad P, Womens Ad Q

### Ads planned for decision week (2026-W05)

* Men: Mens Ad J, Mens Ad O
* Women: Womens Ad P, Womens Ad R

---

## Assessment notes (2026-W04)

* Mens Ad J: 148.53 spend / 4 leads (37.13 CPL) - keep.
* Mens Ad N: 53.96 spend / 1 lead (53.96 CPL); run is 260.67 spend at 52.13 CPL - replace.
* Womens Ad P: 86.55 spend / 3 leads (28.85 CPL) - keep.
* Womens Ad Q: 124.08 spend / 2 leads (62.04 CPL) - replace.

---

## Decisions for 2026-W05

* Keep: Mens Ad J; Womens Ad P.
* Replace Mens Ad N with Mens Ad O (existing materials reshuffle): Shihonage_MF_Dojo_Photo__A.png + "ללמוד לשלוט ברגע" + "Everyday Pressure".
* Replace Womens Ad Q with Womens Ad R (existing materials reshuffle): Illustrated_Calm_Poster_Female.png + "גוף חזק, ראש רגוע" + "Quiet Space - Bullet Calm".
* New-material slot: unused this week.

---

End of Plan for 2026-W05

---

# Plan for 2026‑W04 (assessing 2026‑W03)

### Weeks

- **Assessed (data) week:** 2026‑W04
- **Decision / planned week:** 2026‑W03

### Ads active in assessed week (2026‑W03)

- Men: Mens Ad A, Mens Ad N
- Women: Womens Ad N, Womens Ad O

### Ads planned for decision week (2026‑W04)

- Men: Mens Ad J, Mens Ad N
- Women: Womens Ad P, Womens Ad Q

---

### Rationale (concise)

**Men’s portfolio**

* **Mens Ad J** retained as a stable performer with acceptable historical behavior; no evidence of semantic mismatch or fatigue.
* **Mens Ad N** retained to preserve a second, distinct male creative angle; still early but no negative signal warranting replacement.

**Women’s portfolio**

* **Womens Ad P** introduced as a **pure reshuffle of existing materials**. The goal is incremental learning via a new combination while staying inside previously validated semantic space and without consuming the weekly new‑material allowance.

* **Womens Ad Q** introduced as the **single new‑material ad** for the week:
  
  * New media (instructional interaction with clear female agency)
  * New headline: *עוצמה, איזון, ביטחון עצמי*
  * New text: *Meaningful Movement*
    This decision followed a focused reassessment of image-text alignment around the instructional female‑pair media. Earlier runs with that media showed zero leads but insufficient evidence to attribute failure to copy or headline. The new creative is therefore treated explicitly as a controlled probe of **media + message together**, not as a baseline replacement.

---

### Constraints check

* Creative uniqueness preserved within each campaign.
* Exactly **one** ad contains new material (Womens Ad Q).
* Reused assets traceable to existing attachments.

---

### Notes for next review

* Evaluate Womens Ad Q primarily on **delivery and early lead signal** to determine whether the instructional media can work with stronger, competence‑forward messaging.
* Womens Ad P provides a comparison point using only known components.
* Men’s ads provide continuity for week‑over‑week interpretation.

---

End of plan for 2026-W04

---

# Plan for 2026‑W03 (assessing 2026‑W02)

### Weeks

- **Assessed (data) week:** 2026‑W03
- **Decision / planned week:** 2026‑W02

### Ads active in assessed week (2026‑W02)

- Men: Mens Ad A, Mens Ad N
- Women: Womens Ad N, Womens Ad O

### Ads planned for decision week (2026‑W03)

- Men: Mens Ad A, Mens Ad N
- Women: Womens Ad N, Womens Ad O

---

- **Contiguous runs (as of assessed week end):**
  - Mens Ad A: 2025‑W52 → 2026‑W02 (3 weeks)
  - Mens Ad N: 2026‑W02 → 2026‑W02 (1 week)
  - Womens Ad N: 2026‑W02 → 2026‑W02 (1 week)
  - Womens Ad O: 2026‑W02 → 2026‑W02 (1 week)

### What happened in 2026‑W02

- All four ads delivered meaningful spend (≈48-81 ILS), but **lead counts were low everywhere (1-2 leads/ad)**.
- Mens Ad A showed a **weekly CPL spike (80.7)**, but this was based on **1 lead**; its **current-run CPL remains strong (33.8 over 8 leads)**.
- Womens Ad O produced the best weekly CPL (**23.8 on 2 leads**) with clean image-text alignment.

### Decision for 2026‑W03

**Keep all four currently active ads** (no replacements required this week; preserve new‑material budget).

- **Mens Ad A** - Media: `Shihonage_MF_Dojo_Photo__A.png` (attachment_id=27; sha256=6f84d2a4…) - keep due to strong run-level CPL despite noisy week.
- **Mens Ad N** - Media: `Outside_Sunset_MM_Kaitenage_photo__B.png` (attachment_id=28; sha256=ef37e601…) - keep; early signal is good and outside-photo media performs well in lifetime rollups.
- **Womens Ad N** - Media: `Dojo_Instruction_FemalePair.png` (attachment_id=53; sha256=db735aa7…) - keep; early, low-sample run and spend below strong evidence threshold.
- **Womens Ad O** - Media: `Illustrated_Calm_Poster_Female.png` (attachment_id=38; sha256=97ddbb5d…) - keep; strongest weekly CPL in W02.

### Data hygiene / learning notes

- **Tag integrity risk:** at least one media asset appears to have a Media_Style tag inconsistent with the actual image (e.g., a dojo photo tagged as “Illustration - Poster”). Component/tag learning should be treated cautiously until corrected.

### What would change this decision next week

- If delivery collapses (sharp spend/impressions drop) for a baseline ad, consider a controlled reshuffle.
- If tag-based decisions are desired, prioritize fixing obvious Media_Style / Media_Energy tag mismatches first.

---

End of plan for 2026-W03

---

# Plan for 2026‑W02 (assessing 2026‑W01)

### Weeks

- **Assessed (data) week:** 2026‑W02
- **Decision / planned week:** 2026‑W01

### Ads active in assessed week (2026‑W01)

- Men: Mens Ad A, Mens Ad B
- Women: Womens Ad A, Womens Ad D

### Ads planned for decision week (2026‑W02)

- Men: Mens Ad A, Mens Ad N
- Women: Womens Ad N, Womens Ad O

---

### Context and timing

* **Latest completed data week assessed:** 2026-W01
* **Decision week planned:** 2026-W02
* **Ads launched:** Saturday evening

Operational note:

* From **Thursday through Saturday**, before this decision cycle was fully organized, the following ads continued running:
  
  * **Men:** Mens Ad A, Mens Ad B
  * **Women:** Womens Ad A, Womens Ad D

* This overlap is documented to avoid confusion when interpreting partial‑week performance.

---

### Ads running in 2026-W02

* **Men:** Mens Ad A (kept), Mens Ad N (shuffle)
* **Women:** Womens Ad N (shuffle), Womens Ad O (new text)

---

### Evidence considered

* Weekly and run‑level performance from `performance_data.json` for 2026-W01
* Lifetime ad‑level and tag‑level rollups
* Recent delivery behavior and low‑sample constraints

---

### Decisions

**Keep**

* **Mens Ad A** retained as the anchor ad based on strong weekly and run‑level CPL.

**Shuffle (existing materials only)**

* **Mens Ad N**: new combination of existing media, headline, and text.
* **Womens Ad N**: new combination of existing media, headline, and text.

**New material (one ad only)**

* **Womens Ad O**: new headline and new primary text paired with existing illustrated calm poster media.

---

### Rationale

**Mens Ad A (kept, unchanged)**

* Mens Ad A was retained without modification because it is the only ad that met *both* weekly and run‑level performance criteria with sufficient signal.
* Its media, headline, and text have repeatedly delivered low CPL across multiple weeks, making it the most reliable anchor for the men’s campaign.
* No creative changes were introduced here in order to preserve continuity and to ensure that any changes in overall portfolio performance can be attributed to the exploratory ads rather than disruption of the baseline.

**Mens Ad N (shuffle: media + headline + text)**

* Mens Ad N was created as a **pure reshuffle** of existing components rather than a new-material experiment.
* **Media:** `Dojo_Action_LineArt_Male.png` (existing illustrated dynamic throw; acceptable lifetime CPL; no suppression signals).
* **Headline:** "כוח רגוע מבפנים" (existing men’s headline with strong historical performance).
* **Text:** `Mens_Text_CalmStrength_v2` (existing men’s text emphasizing grounded control and calm strength).
* These components were each previously validated in other combinations but had not been paired together.
* This reshuffle explicitly tests *interaction effects* between known components while minimizing risk in a campaign anchored by Mens Ad A.

**Womens Ad N (shuffle: media + headline + text)**

* Womens Ad N serves as the women’s-campaign analogue of Mens Ad N: a low-risk exploratory reshuffle using only existing materials.
* **Media:** `Dojo_Instruction_FemalePair.png` (existing instructional photo; neutral delivery; semantically flexible).
* **Headline:** "תנועה שמרגישה נכון" (existing women’s headline with stable historical CPL).
* **Text:** `Womens_Text_GentlePractice_v1` (existing supportive, non-competitive framing).
* The goal of this reshuffle is to maintain strong semantic alignment while testing a new combination that has not previously been run.
* This ad provides incremental learning without consuming the single weekly allowance for new material.

**Womens Ad O (new text + headline, existing media)**

* Womens Ad O is the **only ad this week containing new material**, consistent with the weekly constraint.

* **Media:** `Illustrated_Calm_Poster_Female.png` (existing illustrated calm poster; low energy; visually distinct; no recent overuse).

* **New headline:** "מרחב שקט לעצמך" (new; hook = stress / mental load; promise = personal calm; tone = reassuring).

* **New text:** `Womens_Text_CalmPermission_v1`
  
  * Opening line: "מקום לנשום. לא צריך למהר"
  
  * Structure: checklist (three parallel bullets)
  
  * Desire bullets:
    
    * 🌿 תנועה רגועה שמכבדת את הגוף
    * 🌿 אימון רך, תומך ולא תחרותי
    * 🌿 מרחב בטוח לעצור רגע בתוך השבוע
  
  * CTA: "לחצי לפרטים ולהתנסות בשיעור היכרות בלי התחייבות"

* This configuration reflects the hypothesis that recent underperformance in the women’s campaign is driven primarily by **copy fatigue** rather than media failure, and that explicitly permissive calm copy is better matched to this visual than instructional imagery.

**Abandoned alternative (documented explicitly)**

* The preferred initial plan was to pair the **Dojo_Instruction_FemalePair** image with a new headline and text.
* This plan was abandoned because the image had already been posted earlier in the same week, violating the creative‑uniqueness rule.
* As a result, Dojo_Instruction_FemalePair was retained only in a shuffled configuration, and the new copy was reassigned to the illustrated calm poster.

Only one ad includes new material, in line with exploration constraints.

---

### What would change this decision next week

* Any ad producing **<50 ILS CPL over ≥3 leads** becomes a keep candidate.
* Sustained **>65 ILS CPL over ≥3 leads** triggers replacement.
* Clear evidence of media-copy mismatch or delivery suppression may trigger media rotation.

---

### Confidence level

**Moderate-high confidence.**

Decisions balance stability with a single, well‑scoped exploratory change under noisy, low‑budget conditions.

---

End of plan for 2026-W02

---

# Plan for 2026‑W01 (assessing 2025‑W052)

### Weeks

- **Assessed (data) week:** 2025‑W52
- **Decision / planned week:** 2026‑W01

### Ads active in assessed week (2025‑W52)

- Men: Mens Ad A, Mens Ad B
- Women: Womens Ad A, Womens Ad J

### Ads planned for decision week (2026‑W01)

- Men: Mens Ad A, Mens Ad B
- Women: Womens Ad A, Womens Ad D

---

### Context

* Latest completed data week in export: **2025-W52**.
* Campaign changes executed late in the week → expected **low volume and noisy CPLs**.

### Active Portfolio (Entering Week)

* **Women:** Womens Ad A, Womens Ad J
* **Men:** Mens Ad A, Mens Ad B
* **Operational note:** Womens Ad J showed **no delivery** (0 spend).

### Evidence Considered

* All active ads were **low sample size (≤2 leads)**; weekly CPLs not considered decisive.

* Lifetime CPL leaders remain:
  
  * Womens Ad A (~37 ILS)
  * Mens Ad B (~38 ILS)

* Tag rollups show **consistent signal** favoring:
  
  * **Photo - Outside** media
  * **Calm** energy

* Womens Ad J exhibited **delivery collapse**, treated as an operational issue rather than a performance signal.

### Decisions

* **Keep** Mens Ad A unchanged.
* **Keep** Mens Ad B unchanged despite weak weekly CPL (treated as noise).
* **Keep** Womens Ad A as baseline women’s creative.
* **Pause / remove** Womens Ad J due to non-delivery.
* **Reactivate** Womens Ad D as second women’s slot.

### Rationale

* Weekly CPL fluctuations interpreted as noise under low volume.
* Portfolio stability prioritized to allow signal accumulation.
* Womens Ad J swap driven by delivery integrity, not by learning conclusions.

### Deferred Actions

* No new creative generation this week.
* No recombination of text/headline/media components.
* Reason: iteration space not exhausted and insufficient evidence to justify exploration.

### Re-evaluation Triggers (Next Week)

* If **Mens Ad A or B** exceed **60-65 ILS CPL over ≥3 leads**, reassess men’s portfolio.
* If **Womens Ad A or D** exceed **~65 ILS CPL over ≥3 leads**, reassess women’s portfolio.
* If delivery collapses again on baseline ads, consider **Media Seed 1**.

---

### Context snapshot

* Men’s and Women’s lead campaigns running at ~30 ILS/day each.

* Portfolio at start of W52 (post-reset):
  
  * **Men:** Mens Ad A, Mens Ad B
  * **Women:** Womens Ad A, Womens Ad D

* W52 is a **full, closed week**. W53 is the upcoming run week.

* Conversion rollups (Has trial / Has registrations / Failures) are now present but still sparse and treated as exploratory telemetry.

---

### Observed performance (W52)

**Men**

* **Mens Ad A:** 2 leads, CPL ≈47 ILS.
* **Mens Ad B:** 1 lead, CPL ≈129 ILS.
* Neither ad reached the ≥3‑lead threshold required for CPL‑based reassessment.
* Mens Ad B’s W52 result is inconsistent with its strong lifetime CPL and treated as week‑level noise.

**Women**

* **Womens Ad A:** 1 lead, CPL ≈76 ILS (above target but below reassessment lead threshold).
* **Womens Ad D:** ~146 ILS spend, **0 leads**, normal delivery.
* Zero‑lead outcome at this spend level is treated as a meaningful negative signal, distinct from high‑CPL noise.

---

### Decision taken

* **Men:** No change.
  
  * Continue **Mens Ad A** and **Mens Ad B** unchanged.

* **Women:** Rotate portfolio.
  
  * Remove **Womens Ad D**.
  * Activate **Womens Ad J** in its original configuration.
  * Keep **Womens Ad A** unchanged.

* No new creatives generated.

* No recombination of text, headline, or media components.

---

### Primary rationale

* Decision rules based on ≥3 leads remain appropriate for high‑CPL evaluation.
* However, sustained **zero‑lead spend (~120-150 ILS) with normal delivery** constitutes a separate failure mode and justifies conservative rotation.
* Mens portfolio does not meet any reassessment trigger.
* Womens Ad D shows insufficient evidence to justify continued budget allocation when proven alternatives exist.
* Action favors portfolio hygiene over exploration.

---

### Alternatives explicitly rejected

* Keeping **Womens Ad D** for another full week: rejected due to zero‑lead spend magnitude.
* Generating new creatives: rejected because historical options are not exhausted.
* Component‑level recombination: rejected due to lack of clean, isolatable signal.

---

### Clarification added to decision rules (implicit)

* Ads that accumulate **~120-150 ILS with zero leads and normal delivery** may be rotated out even if CPL‑over‑≥3‑leads criteria are not met.

---

### What would change this decision next week

* If **Mens Ad A or B** exceed ~60-65 ILS CPL over ≥3 leads, reassess men’s portfolio.
* If **Womens Ad A or J** exceed ~65 ILS CPL over ≥3 leads, reassess women’s portfolio.
* If baseline delivery collapses (suppression or sharp impression drop), consider Media Seed 1.
* If baseline ads stabilize but CPL trends upward across weeks, consider controlled recombination before new creative generation.

---

### Confidence level

**High confidence.**

Decision is conservative, evidence‑aligned, and consistent with stability‑first portfolio management.

---

End of plan for 2026-W01

---

# Plan for 2025‑W52 (assessing 2025‑W51)

### Weeks

- **Assessed (data) week:** 2025‑51
- **Decision / planned week:** 2025‑W52

### Ads active in assessed week (2026‑W51)

- Men: Mens Ad K, Mens Ad M
- Women: Womens Ad M, Womens Ad G

### Ads planned for decision week (2025‑W52)

- Men: Mens Ad A, Mens Ad B
- Women: Womens Ad A, Womens Ad D

---

## Context snapshot

* Men’s and Women’s lead campaigns running at ~30 ILS/day each.

* At start of week, active creatives were:
  
  * **Men:** Mens Ad K, Mens Ad M
  * **Women:** Womens Ad M, Womens Ad G

* W51 data incomplete and treated as provisional.

---

## What changed since last decision

* **Mens Ad K** accumulated ~125 ILS across W50-W51 with **zero leads** (no longer low-sample).
* **Mens Ad M** produced leads but at elevated CPL (≈65 in W50, ≈95 in W51 provisional).
* **Womens Ad M** remained stable but expensive (≈71-73 CPL across W50-W51; 4 total leads).
* **Womens Ad G** produced 1 lead at low CPL in W51, but remains a single-event result.

---

## Decision taken

* **Men:** Remove Mens Ad K and Mens Ad M.
  
  * Activate **Mens Ad A** and **Mens Ad B** in their original configurations.

* **Women:** Remove Womens Ad M.
  
  * Activate **Womens Ad A** and **Womens Ad D** in their original configurations.

* No new creatives generated.

* No recombination of existing components.

---

## Primary rationale

* Recent underperformance is best explained at the **ad level**, not the component level.
* Multiple historically strong creatives are available and currently inactive.
* Evidence does not yet justify exploration or creative novelty.
* This week is treated as a **portfolio reset**, not an iteration or exploration phase.

---

## Alternatives explicitly rejected

* **Recombining components** from Mens K/M or Womens M/G: rejected due to lack of clear component-level signal.
* **Generating new text, headline, or media:** rejected because proven baseline creatives are not exhausted.
* **Keeping Womens Ad G** based on W51 performance: rejected due to single-lead sample size.

---

## What would change this decision next week

* If Mens Ad A or B exceed ~60-65 ILS CPL over ≥3 leads, reassess men’s portfolio.
* If Womens Ad A or D exceed ~65 ILS CPL over ≥3 leads, reassess women’s portfolio.
* If delivery collapses on baseline ads (suppression or sharp impression drop), consider Media Seed 1.
* If baseline ads stabilize but CPL trends upward across weeks, consider controlled recombination or new creative generation.

---

## Confidence level

**High confidence.**

Decision favors evidence-backed stability over novelty in a noisy, low-budget environment.

---

End of plan for 2025-W52

---
